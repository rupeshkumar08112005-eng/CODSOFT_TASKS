# CodSoft C++ Programming Internship Tasks

This folder contains three console-based C++ projects selected from the CodSoft task brief:

1. **Task 1 – Number Guessing Game**
2. **Task 2 – Simple Calculator**
3. **Task 4 – To-Do List**

## Requirements
- A C++ compiler such as GCC (`g++`)
- Visual Studio Code (or another C++ editor)

## Compile and run in the VS Code terminal

Open this folder in VS Code, then run the commands below one project at a time.

### Task 1
```bash
g++ Task1_Number_Guessing_Game.cpp -o task1
./task1
```
On Windows PowerShell, run the program with:
```powershell
.\task1.exe
```

### Task 2
```bash
g++ Task2_Simple_Calculator.cpp -o task2
./task2
```
On Windows PowerShell:
```powershell
.\task2.exe
```

### Task 4
```bash
g++ Task4_To_Do_List.cpp -o task4
./task4
```
On Windows PowerShell:
```powershell
.\task4.exe
```

## Features
- **Number Guessing Game:** generates a random number from 1 to 100, gives higher/lower hints, and counts attempts.
- **Simple Calculator:** supports addition, subtraction, multiplication, and division, including division-by-zero handling.
- **To-Do List:** lets users add, view, complete, and delete tasks.

## Before submitting
- Compile and run each program on your own computer.
- Try normal inputs and invalid inputs.
- Record a short screen demo showing each program running.
- Create a GitHub repository using the exact repository name/instructions provided by CodSoft, upload these files, and use the repository URL in the submission form.
- Add your own short explanation of what you learned. Do not claim tests or work you have not personally completed.
